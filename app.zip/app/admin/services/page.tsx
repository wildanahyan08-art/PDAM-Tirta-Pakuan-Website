import { getCookies } from "@/helper/cookies";
import Link from "next/link";
import Search from "./search";
import Drop from "./drop";

/* ================= TYPES ================= */

export interface ServiceResponse {
  success: boolean;
  message: string;
  data: ServiceType[];
  count: number;
}

export interface ServiceType {
  id: number;
  name: string;
  min_usage: number;
  max_usage: number;
  price: number;
  owner_token: string;
  createdAt: string;
  updatedAt: string;
}

/* ================= FETCH ================= */

async function getServices(): Promise<ServiceResponse> {
  try {
    const url = `${process.env.NEXT_PUBLIC_BASE_URL}/services`;
    const response = await fetch(url, {
      method: "GET",
      cache: "no-store",
      headers: {
        "app-key": process.env.NEXT_PUBLIC_APP_KEY || "",
        Authorization: `Bearer ${await getCookies("token")}`,
      },
    });

    const responseData: ServiceResponse = await response.json();

    if (!response.ok) {
      return {
        success: false,
        message: responseData.message,
        data: [],
        count: 0,
      };
    }

    return responseData;
  } catch {
    return {
      success: false,
      message: "Failed to fetch services",
      data: [],
      count: 0,
    };
  }
}

/* ================= PAGE ================= */
type PageProp = {
  searchParams: Promise<{
    search?: string;
  }>;
};

export default async function AdminServicesPage(props: PageProp) {
  const { search } = await props.searchParams;
  const response = await getServices();

  if (!response.success) {
    return (
      <div className="min-h-screen bg-gray-50 px-6 py-10">
        <div className="max-w-5xl mx-auto">
          <div className="rounded-lg bg-red-50 border border-red-200 p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="h-10 w-10 rounded-full bg-red-100 flex items-center justify-center">
                  <div className="h-5 w-5 text-red-600">⚠️</div>
                </div>
              </div>
              <div className="ml-4">
                <h3 className="text-lg font-medium text-red-800">Error</h3>
                <p className="text-red-700 mt-1">{response.message}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Filter data berdasarkan search keyword di CLIENT SIDE
  const filteredServices = search
    ? response.data.filter(
        (service) =>
          service.name.toLowerCase().includes(search.toLowerCase()) ||
          service.id.toString().includes(search) ||
          service.price.toString().includes(search),
      )
    : response.data;

  return (
    <div className="min-h-screen bg-gray-50 px-4 py-8">
      <div className="max-w-7xl mx-auto">
        {/* HEADER */}
        <div className="mb-8">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                Daftar Layanan
              </h1>
              <p className="text-gray-600 mt-1">
                Total: {response.data.length} layanan
                {search && (
                  <span className="text-blue-600 ml-2">
                    • Pencarian: &quot;{search}&quot; ({filteredServices.length}{" "}
                    ditemukan)
                  </span>
                )}
              </p>
            </div>
            <Link
              href="/admin/services/add"
              className="inline-flex items-center justify-center px-4 py-2.5 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors shadow-sm"
            >
              <span className="mr-2">+</span>
              Tambah Layanan
            </Link>
          </div>

          {/* Search Component */}
          <div className="mb-6">
            <Search search={search || ""} />
          </div>
        </div>

        {/* SERVICE LIST */}
        {filteredServices.length === 0 ? (
          <div className="bg-white rounded-lg border border-gray-200 p-8 text-center">
            <div className="max-w-md mx-auto">
              <div className="h-16 w-16 mx-auto bg-gray-100 rounded-full flex items-center justify-center mb-4">
                <div className="text-2xl">📭</div>
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                {search ? "Hasil tidak ditemukan" : "Tidak ada layanan"}
              </h3>
              <p className="text-gray-600 mb-6">
                {search
                  ? `Tidak ditemukan dengan kata kunci "${search}"`
                  : "Belum ada data layanan"}
              </p>
              {search ? (
                // Ganti dengan Link untuk menghindari hydration error
                <Link
                  href="/admin/services"
                  className="inline-block px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
                >
                  Reset Pencarian
                </Link>
              ) : (
                <Link
                  href="/admin/services/add"
                  className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  <span className="mr-2">+</span>
                  Buat Layanan
                </Link>
              )}
            </div>
          </div>
        ) : (
          <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
            {/* Table Header */}
            <div className="hidden md:grid grid-cols-12 bg-gray-50 px-6 py-3 border-b border-gray-200">
              <div className="col-span-2 text-sm font-medium text-gray-500">
                ID
              </div>
              <div className="col-span-3 text-sm font-medium text-gray-500">
                Nama Layanan
              </div>
              <div className="col-span-2 text-sm font-medium text-gray-500">
                Min Usage
              </div>
              <div className="col-span-2 text-sm font-medium text-gray-500">
                Max Usage
              </div>
              <div className="col-span-2 text-sm font-medium text-gray-500">
                Harga
              </div>
              <div className="col-span-1 text-sm font-medium text-gray-500 text-right">
                Aksi
              </div>
            </div>

            {/* Table Body */}
            <div className="divide-y divide-gray-200">
              {filteredServices.map((service) => (
                <div
                  key={service.id}
                  className="grid grid-cols-1 md:grid-cols-12 px-6 py-4 hover:bg-gray-50 transition-colors"
                >
                  {/* Mobile View */}
                  <div className="md:hidden space-y-3">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-medium text-gray-900">
                          {service.name}
                        </h3>
                        <p className="text-sm text-gray-500">
                          ID: #{service.id}
                        </p>
                      </div>
                      <div className="flex space-x-2">
                        <Link
                          href={`/admin/services/edit/${service.id}`}
                          className="px-3 py-1.5 text-sm bg-blue-100 text-blue-700 rounded hover:bg-blue-200 transition-colors"
                        >
                          Edit
                        </Link>
                        <Drop
                          serviceId={service.id}
                          serviceName={service.name}
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <p className="text-xs text-gray-500">Min</p>
                        <p className="font-medium">{service.min_usage}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500">Max</p>
                        <p className="font-medium">{service.max_usage}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500">Harga</p>
                        <p className="font-medium">
                          Rp {service.price.toLocaleString()}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Desktop View */}
                  <div className="hidden md:contents">
                    <div className="col-span-2 flex items-center">
                      <span className="px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                        #{service.id}
                      </span>
                    </div>
                    <div className="col-span-3 flex items-center">
                      <div>
                        <p className="font-medium text-gray-900">
                          {service.name}
                        </p>
                        <p className="text-xs text-gray-500">
                          {new Date(service.createdAt).toLocaleDateString(
                            "id-ID",
                          )}
                        </p>
                      </div>
                    </div>
                    <div className="col-span-2 flex items-center">
                      <p className="text-gray-900 font-medium">
                        {service.min_usage}
                      </p>
                    </div>
                    <div className="col-span-2 flex items-center">
                      <p className="text-gray-900 font-medium">
                        {service.max_usage}
                      </p>
                    </div>
                    <div className="col-span-2 flex items-center">
                      <p className="text-gray-900 font-medium">
                        Rp {service.price.toLocaleString("id-ID")}
                      </p>
                    </div>
                    <div className="col-span-1 flex items-center justify-end space-x-2">
                      <Link
                        href={`/admin/services/edit/${service.id}`}
                        className="px-3 py-1.5 text-sm bg-blue-100 text-blue-700 rounded hover:bg-blue-200 transition-colors"
                      >
                        Edit
                      </Link>
                      <Drop serviceId={service.id} serviceName={service.name} />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="mt-6 text-sm text-gray-500">
          Menampilkan {filteredServices.length} dari {response.data.length}{" "}
          layanan
          {search && <span className="ml-2 font-medium">(difilter)</span>}
        </div>
      </div>
    </div>
  );
}